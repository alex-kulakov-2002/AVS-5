
#ifndef Beehive_class
#define Beehive_class

#include "mutex"
#include "Bee.h"
#include "Bear.h"
#include "thread"

class Bee;

class Beehive {
    clock_t time_start;
    int number_of_steal;
    std::mutex mtx;
    int number_of_honey = 0;
    int bee_in_beehive = 0;
public:
    Beehive();
    void start(int number_of_bee, int time_bee_to_collect_honey, int time_bear_healing);
    void add_honey();
    bool try_to_steal_honey();
    void bee_come();
    void bee_leave();
};


#endif
