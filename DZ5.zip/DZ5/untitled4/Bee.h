


#ifndef Bee_class
#define Bee_class

#include "Beehive.h"
#include "thread"
#include "chrono"
#include "random"

class Beehive;

class Bee {

    bool isInBeehive;
    Beehive *beehive;
    int time_for_collecting_honey;
public:
    Bee(Beehive *beehive1, int time_for_collecting_honey);
    void start();
};


#endif
