#ifndef Bear_class
#define Bear_class

#include "Beehive.h"
#include "thread"
#include "chrono"

class Beehive;

class Bear {
    int time_for_healing;
    Beehive *beehive;

public:
    Bear(Beehive *beehive1, int time_for_healing);
    void start();
};


#endif
